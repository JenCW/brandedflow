# Company Creation Kit — Plain-English Glossary (Marketing + AI)

Date: 2025-12-07

## Marketing words → normal words
- **Brand** = what people remember about you + what they expect from you  
- **Positioning** = who it’s for and why you, in one clean sentence  
- **Messaging** = the words you use repeatedly so people “get it” fast  
- **Offer** = what you sell and what they get  
- **Funnel** = the path from “never heard of you” to “paid”  
- **Nurture** = staying in touch so they trust you when they’re ready  
- **Conversion** = they take the next step (not always buying)

## AI words → normal words
- **AI** = a helper that drafts, sorts, summarizes, and speeds up thinking  
- **Prompt** = your instructions to the helper  
- **Agent** = AI that can take multi-step actions (when allowed)  
- **Workflow** = a repeatable set of steps  
- **Automation** = rules that run the workflow without you pushing buttons  
- **CRM** = the place contacts/leads live so they don’t disappear  
- **Sequence** = timed messages that go out automatically

## The “so what?”
If you can:
1) say what you do clearly (brand), and  
2) follow up without effort (automation),  
you win—because consistency beats talent when life gets messy.
