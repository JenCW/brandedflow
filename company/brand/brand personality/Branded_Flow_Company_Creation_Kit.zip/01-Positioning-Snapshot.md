# Company Creation Kit — Positioning Snapshot (Plain English)

**Use this to define what you do in a way normal humans understand.**  
Date: 2025-12-07

## 1) The real problem (what they’re feeling)
**My customers feel:**  
- [ ] Overwhelmed  
- [ ] Anxious  
- [ ] Behind / embarrassed  
- [ ] Exhausted  
- [ ] Stuck / confused  
- [ ] Lonely doing it all

**Because:**  
- They don’t understand “marketing speak” and feel judged.  
- AI feels like a moving train they can’t catch.  
- They don’t know what to do first, so they do nothing.

## 2) Who we help (no titles, describe the situation)
We help: **__________________________________________**  
Examples: “service-based owners doing everything themselves”, “local business owners who rely on referrals”, “coaches with messy intake/follow-up”.

## 3) What we help them get (the relief)
After working with us, they get:  
- **Clarity:** _________________________________________  
- **Follow-through:** __________________________________  
- **Results:** _________________________________________  
- **Relief:** __________________________________________

## 4) What we actually do (in one sentence)
We help ____________________ who feel ____________________ by ____________________ so they can ____________________.

## 5) The “translation” promise (your differentiation)
Most options in your market:  
- teach concepts, sell hype, drown people in tools

**We do:**  
- translate the jargon  
- pick the few moves that matter  
- implement the system  
- make it stick

## 6) Your 3 outcomes (measurable)
1) _________________________________________________  
2) _________________________________________________  
3) _________________________________________________  

## 7) Your proof (why you’re credible)
- What have you built/done that proves you can solve this?  
  ____________________________________________________  
- What’s your “I’ve seen this 100 times” insight?  
  ____________________________________________________

## 8) Your anti-promise (what you’re NOT)
We are not:  
- a hype machine  
- a “post every day” content sweatshop  
- a tool collector  
- a done-with-you course that leaves you stuck

## 9) Call to action (one simple next step)
The next step is: **____________________________________**  
Examples: “fill out the intake form”, “book a 15-min fit check”, “request a build quote”.
