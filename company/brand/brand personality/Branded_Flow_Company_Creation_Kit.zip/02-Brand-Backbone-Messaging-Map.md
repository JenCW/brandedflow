# Company Creation Kit — Brand Backbone (Messaging Map)

Date: 2025-12-07

## A) Your “front door” message (website / bio / intro)
**One-liner:**  
______________________________________________________

**Two-liner (feeling → relief):**  
______________________________________________________  
______________________________________________________

## B) Your message pillars (3–5 things you repeat forever)
1) **Pillar:** ____________________  
   - What you mean in plain words: ____________________  
   - Example proof/story: _____________________________  
2) **Pillar:** ____________________  
   - Plain words: ____________________________________  
   - Proof/story: ____________________________________  
3) **Pillar:** ____________________  
   - Plain words: ____________________________________  
   - Proof/story: ____________________________________

## C) The “feelings” you speak to (use their words)
- “I feel ____________________________________________”
- “I’m scared _________________________________________”
- “I can’t keep up because _____________________________”
- “I don’t even know where to start with _______________”

## D) The “translation” lines (marketing + AI → real life)
**Marketing, translated:**  
- “Marketing” = getting the right people to understand you + take the next step.  
- “Strategy” = what we will do first, second, third.  
- “Funnel” = how strangers become clients.

**AI, translated:**  
- “AI” = a helper that drafts, sorts, summarizes, and saves time.  
- “Automations” = if-this-then-that rules so the business runs without you pushing every button.

## E) Your offer names (make them normal)
Offer 1 name: ____________________  
Offer 2 name: ____________________  
Offer 3 name: ____________________

## F) Your “why you” (no bragging, just truth)
People choose us because:  
- ____________________________________________________  
- ____________________________________________________  
- ____________________________________________________

## G) Your boundaries (this is leadership)
We work best when:  
- ____________________________________________________  
We don’t do:  
- ____________________________________________________
