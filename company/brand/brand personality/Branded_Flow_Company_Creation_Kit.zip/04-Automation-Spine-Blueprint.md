# Company Creation Kit — Automation Spine Blueprint (Simple + Reusable)

Date: 2025-12-07

**Goal:** stop dropped balls. create predictable follow-through. reduce anxiety.

## 1) Intake (how leads enter)
Lead sources (check all):  
- [ ] Website form  
- [ ] Instagram/DM  
- [ ] Email  
- [ ] Referrals  
- [ ] Ads  
- [ ] Other: _____________

**Single source of truth (your CRM):** __________________________

## 2) The spine (if-this-then-that)
### Trigger 1: New lead captured
When: _______________________________________________  
Then:
- Create/update contact in CRM  
- Tag/source = ______________________  
- Send confirmation message (email/text)  
- Notify owner (Slack/email)  
- Start nurture sequence

### Trigger 2: Discovery requested / fit check
When: _______________________________________________  
Then:
- Send scheduling link or “reply with 3 times”  
- Send pre-call questions (short)  
- Create task “Prep: read form”

### Trigger 3: Proposal sent
When: _______________________________________________  
Then:
- Start follow-up sequence: Day 2 / Day 5 / Day 10  
- If no response by Day 10 → “close loop” message

### Trigger 4: Payment received
When: _______________________________________________  
Then:
- Send welcome + next steps  
- Create client folder  
- Create ClickUp project/tasks  
- Start onboarding sequence

### Trigger 5: Client onboarding complete
When: _______________________________________________  
Then:
- Start delivery cadence (weekly update reminder)  
- Start review/referral request after X days

## 3) Minimum viable sequences (copy/paste goals)
**Confirmation:** “Got it. Here’s what happens next.”  
**Nurture:** “Here’s a helpful tip / example / proof.”  
**Follow-up:** “Still want help with this? Reply YES and I’ll send next step.”

## 4) Owner-friendly rules (anti-overwhelm)
- One CRM. One intake form. One follow-up system.  
- No manual follow-up unless the system fails.  
- Every trigger creates a task so nothing lives in memory.

## 5) Metrics (to know it’s working)
- Leads captured per week: _____  
- Response time: _____  
- Show rate: _____  
- Close rate: _____  
- Time saved per week: _____
